import os
import csv

# ========== File Configuration ==========
DATA_FILE = "students.csv"

# ========== Initialize File ==========
def init_file():
    """Create CSV file with headers if it doesn't exist"""
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['ID', 'Name', 'Age', 'Grade', 'Course'])
        print("Student file created successfully!")

# ========== CREATE Operation ==========
def add_student():
    """Add a new student record"""
    print("\n" + "="*40)
    print("        ADD NEW STUDENT")
    print("="*40)
    
    try:
        # Get student ID
        student_id = input("Enter Student ID (e.g., S001): ").strip().upper()
        if not student_id:
            print("Error: Student ID cannot be empty!")
            return
        
        # Check if ID already exists
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                reader = csv.reader(f)
                next(reader)
                for row in reader:
                    if row[0] == student_id:
                        print("Error: Student ID already exists!")
                        return
        
        # Get student name
        name = input("Enter Student Name: ").strip().title()
        if not name:
            print("Error: Name cannot be empty!")
            return
        
        # Get age with validation
        try:
            age = int(input("Enter Age: "))
            if age < 5 or age > 100:
                print("Error: Age must be between 5 and 100!")
                return
        except ValueError:
            print("Error: Please enter a valid age!")
            return
        
        # Get grade and course
        grade = input("Enter Grade (A, B+, etc.): ").strip().upper()
        course = input("Enter Course Name: ").strip().title()
        
        # Save to file
        with open(DATA_FILE, 'a', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow([student_id, name, age, grade, course])
        
        print(f"\nStudent '{name}' added successfully!")
        
    except Exception as e:
        print(f"Error: {e}")

# ========== READ Operation ==========
def show_all_students():
    """Display all student records"""
    print("\n" + "="*60)
    print("        ALL STUDENT RECORDS")
    print("="*60)
    
    try:
        if not os.path.exists(DATA_FILE):
            print("No student records found!")
            return
        
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            headers = next(reader)
            
            print(f"\n{headers[0]:<10} {headers[1]:<20} {headers[2]:<6} {headers[3]:<8} {headers[4]:<15}")
            print("-"*65)
            
            count = 0
            for row in reader:
                print(f"{row[0]:<10} {row[1]:<20} {row[2]:<6} {row[3]:<8} {row[4]:<15}")
                count += 1
            
            print("-"*65)
            print(f"Total Students: {count}")
            
    except Exception as e:
        print(f"Error: {e}")

# ========== UPDATE Operation ==========
def update_student():
    """Update an existing student record"""
    print("\n" + "="*40)
    print("        UPDATE STUDENT")
    print("="*40)
    
    student_id = input("Enter Student ID to update: ").strip().upper()
    
    try:
        if not os.path.exists(DATA_FILE):
            print("No student records found!")
            return
        
        # Read all students
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            headers = next(reader)
            students = list(reader)
        
        # Find and update
        found = False
        for i, student in enumerate(students):
            if student[0] == student_id:
                found = True
                print(f"\nCurrent Record:")
                print(f"  Name: {student[1]}")
                print(f"  Age: {student[2]}")
                print(f"  Grade: {student[3]}")
                print(f"  Course: {student[4]}")
                
                print("\nEnter new values (press Enter to keep current):")
                
                new_name = input(f"  Name [{student[1]}]: ").strip()
                if new_name:
                    student[1] = new_name.title()
                
                new_age = input(f"  Age [{student[2]}]: ").strip()
                if new_age:
                    try:
                        age_val = int(new_age)
                        if 5 <= age_val <= 100:
                            student[2] = str(age_val)
                    except:
                        pass
                
                new_grade = input(f"  Grade [{student[3]}]: ").strip()
                if new_grade:
                    student[3] = new_grade.upper()
                
                new_course = input(f"  Course [{student[4]}]: ").strip()
                if new_course:
                    student[4] = new_course.title()
                
                break
        
        if not found:
            print(f"Student with ID '{student_id}' not found!")
            return
        
        # Write back to file
        with open(DATA_FILE, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerows(students)
        
        print(f"\nStudent updated successfully!")
        
    except Exception as e:
        print(f"Error: {e}")

# ========== DELETE Operation ==========
def delete_student():
    """Delete a student record"""
    print("\n" + "="*40)
    print("        DELETE STUDENT")
    print("="*40)
    
    student_id = input("Enter Student ID to delete: ").strip().upper()
    
    try:
        if not os.path.exists(DATA_FILE):
            print("No student records found!")
            return
        
        # Read all students
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            headers = next(reader)
            students = list(reader)
        
        # Find and delete
        found = False
        deleted_name = ""
        updated_students = []
        
        for student in students:
            if student[0] == student_id:
                found = True
                deleted_name = student[1]
                continue
            updated_students.append(student)
        
        if not found:
            print(f"Student with ID '{student_id}' not found!")
            return
        
        # Confirm deletion
        confirm = input(f"\nAre you sure you want to delete '{deleted_name}'? (y/n): ").lower()
        if confirm != 'y':
            print("Deletion cancelled!")
            return
        
        # Write back without deleted student
        with open(DATA_FILE, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerows(updated_students)
        
        print(f"\nStudent '{deleted_name}' deleted successfully!")
        
    except Exception as e:
        print(f"Error: {e}")

# ========== SEARCH Operation ==========
def search_student():
    """Search for a student by ID"""
    print("\n" + "="*40)
    print("        SEARCH STUDENT")
    print("="*40)
    
    student_id = input("Enter Student ID to search: ").strip().upper()
    
    try:
        if not os.path.exists(DATA_FILE):
            print("No student records found!")
            return
        
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            headers = next(reader)
            
            for row in reader:
                if row[0] == student_id:
                    print("\n" + "="*40)
                    print("STUDENT FOUND:")
                    print("="*40)
                    print(f"ID     : {row[0]}")
                    print(f"Name   : {row[1]}")
                    print(f"Age    : {row[2]}")
                    print(f"Grade  : {row[3]}")
                    print(f"Course : {row[4]}")
                    print("="*40)
                    return
            
            print(f"Student with ID '{student_id}' not found!")
            
    except Exception as e:
        print(f"Error: {e}")

# ========== Main Menu ==========
def main():
    print("="*50)
    print("     STUDENT MANAGEMENT SYSTEM")
    print("     File Handling with CSV")
    print("="*50)
    
    # Initialize the file
    init_file()
    
    while True:
        print("\n" + "-"*40)
        print("MAIN MENU")
        print("-"*40)
        print("1. Add Student (CREATE)")
        print("2. Show All Students (READ)")
        print("3. Update Student (UPDATE)")
        print("4. Delete Student (DELETE)")
        print("5. Search Student")
        print("6. Exit")
        print("-"*40)
        
        choice = input("\nEnter your choice (1-6): ")
        
        if choice == "1":
            add_student()
        elif choice == "2":
            show_all_students()
        elif choice == "3":
            update_student()
        elif choice == "4":
            delete_student()
        elif choice == "5":
            search_student()
        elif choice == "6":
            print("\n" + "="*50)
            print("     Thank you for using Student Management System!")
            print("     Data saved to students.csv")
            print("     Goodbye!")
            print("="*50)
            break
        else:
            print("Error: Invalid choice! Please select 1-6")
        
        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main()