## Project Title
File Handling in Student Record Management System

## Description
A complete student management system that demonstrates CRUD operations using file handling with CSV storage.

## Programming Language
Python 3

## File Format
CSV (students.csv)

## Features

### CRUD Operations:
1. CREATE - Add new student with validation
2. READ - Display all student records
3. UPDATE - Modify existing student records
4. DELETE - Remove student records
5. SEARCH - Find student by ID

### File Handling Features:
- Automatic file creation
- Data persists between program runs
- Exception handling for file operations

## How to Run
1. Open command prompt
2. Navigate to source_code folder
3. Run: python student_management.py

## Sample Output
==================================================
     STUDENT MANAGEMENT SYSTEM
     File Handling with CSV
==================================================

MAIN MENU
----------------------------------------
1. Add Student (CREATE)
2. Show All Students (READ)
3. Update Student (UPDATE)
4. Delete Student (DELETE)
5. Search Student
6. Exit

Enter your choice (1-6): 1

======== ADD NEW STUDENT ========
Enter Student ID (e.g., S001): S001
Enter Student Name: Ali Raza
Enter Age: 20
Enter Grade: A
Enter Course: Computer Science

Student 'Ali Raza' added successfully!

## GitHub Structure
Assignment-2-File-Handling/
├── theory.pdf
├── source_code/
│   └── student_management.py
├── data/
│   └── students.csv
└── README.md